// pages/decor/comment/comment.js
 /**
 * 获取系统信息
 */
//index.js
//CSDN微信小程序开发专栏:http://blog.csdn.net/column/details/13721.html
//获取应用实例

/*
var app = getApp()
Page({
  data: {
    stars: [0, 1, 2, 3, 4],
    normalSrc: '../../../images/star/star0.png',
    selectedSrc: '../../../images/star/star1.png',
    halfSrc: '../../../images/star/star0.5.png',
    key: 0,//评分
  },
  onLoad: function () {
  },
  //点击右边,半颗星
  selectLeft: function (e) {
    var key = e.currentTarget.dataset.key
    if (this.data.key == 0.5 && e.currentTarget.dataset.key == 0.5) {
      //只有一颗星的时候,再次点击,变为0颗
      key = 0;
    }
    console.log("得" + key + "分")
    this.setData({
      key: key
    })

  },
  //点击左边,整颗星
  selectRight: function (e) {
    var key = e.currentTarget.dataset.key
    console.log("得" + key + "分")
    this.setData({
      key: key
    })
  }
})
*/
// pages/more/feedback.js
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    // 评价图片
    evaluationImgUrl: "../../../images/logo/logo3.png",
    starCheckedImgUrl: "../../../images/star/star1.png",
    starUnCheckedImgUrl: "../../../images/star/star0.png",
 
    // 建议内容
    opinion: "",
 
    starMap: [
      '非常差',
      '差',
      '一般',
      '好',
      '非常好',
    ],
 
    evaluations: [
      {
        id: 0,
        name: "驾驶技术",
        image: "../../../images/logo/logo13.png",
        star: 0,
        note: ""
      },
      {
        id: 1,
        name: "服务态度",
        image: "../../../images/logo/logo13.png",
        star: 0,
        note: ""
      },
      {
        id: 2,
        name: "专业程度",
        image: "../../../images/logo/logo13.png",
        star: 0,
        note: ""
      }
    ]
  },
 
  /**
   * 评分
   */
  chooseStar: function (e) {
    const index = e.currentTarget.dataset.index;
    const star = e.target.dataset.star;
    let evaluations = this.data.evaluations;
    let evaluation = evaluations[index];
    // console.log(evaluation)
    evaluation.star = star;
    evaluation.note = this.data.starMap[star-1];
    this.setData({
      evaluations: evaluations
    })
  }
})
