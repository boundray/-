// pages/order/order.js
var app = getApp();
var cardTeams;
const db = wx.cloud.database();
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    currtab: 0,
    swipertab: [{ name: '资讯', index: 0 }, { name: '车友圈', index: 1 }],
     },

 //index.js
//获取应用实例


 

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
 
    
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // 页面渲染完成
    this.getDeviceInfo()
    this.orderShow()
  },
 
  getDeviceInfo: function () {
    let that = this
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          deviceW: res.windowWidth,
          deviceH: res.windowHeight
        })
      }
    })
  },
 
  /**
  * @Explain：选项卡点击切换
  */
  tabSwitch: function (e) {
    var that = this
    if (this.data.currtab === e.target.dataset.current) {
      return false
    } else {
      that.setData({
        currtab: e.target.dataset.current
      })
    }
  },
 fatie:function (event){
  wx.navigateTo({
    url: '/pages/writepo2/writepo2'
  })
  },
  tabChange: function (e) {
    this.setData({ currtab: e.detail.current })
    this.orderShow()
  },
  adddata:function (event){
    wx.cloud.database().collection('project').add({
      // data 字段表示需新增的 JSON 数据
      data: {
         _id: '2', // 可选自定义 _id，在此处场景下用数据库自动分配的就可以

        projectname:"第二阶段 培训车感",
        projectcontent:"1 .感觉车速和车轮的位置 2 .车距判断和看后视镜 3 .车道和行驶位置、速度感知、预测险情、跟车行驶、安全距富 4 .变速、跟车、停车"
                
      
      },

      success: function(res) {
        // res 是一个对象，其中有 _id 字段标记刚创建的记录的 id
        console.log(res)
      }
    })
    },
  orderShow: function () {
    let that = this
    switch (this.data.currtab) {
      case 0:
        that.alreadyShow()
        break
      case 1:
        that.lostShow()
        break
    }
  },
  alreadyShow: function(){
    var that=this;
    db.collection('zixun').get({
      success: function(res) {
        // res.data 是一个包含集合中有权限访问的所有记录的数据，不超过 20 条
        console.log("成功！",res.data);
        that.setData({
          mine:res.data
        })
      }
    })
  },
  xiangqing: function (event){
    console.log("lala",event.currentTarget.dataset.item._id)
    wx.navigateTo({
    url: '/pages/po2/po2?id='+event.currentTarget.dataset.item._id,
    })
    },
 
    xiangqing2: function (event){
      console.log("lala",event.currentTarget.dataset.item._id)
      wx.navigateTo({
      url: '/pages/po/po?id='+event.currentTarget.dataset.item._id,
      })
      },
  lostShow: function () {
    var that=this;
    db.collection('post').get({
      success: function(res) {
        // res.data 是一个包含集合中有权限访问的所有记录的数据，不超过 20 条
        console.log("成功.",res.data);
        that.setData({
          miner:res.data
        })
      }
    })
  },
 
  
})
