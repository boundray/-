var con = require("../../../utils/data.js");
var app = getApp();
const db = wx.cloud.database();
// index/list.js
Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    tabTxt: ['车型', '价格', '星级'],//分类
    tab: [true, true, true],
    pinpai_id: 0,//车型
    pinpai_txt: '',
    jiage_id: 0,//价格
    jiage_txt: '',
    xiaoliang_id: 0,//星级
    xiaoliang_txt: '',
    mine:[],
  },
 
  // 选项卡
  filterTab: function (e) {
    var data = [true, true, true], index = e.currentTarget.dataset.index;
    data[index] = !this.data.tab[index];
    this.setData({
      tab: data
    })
  },
  onLoad: function (options) {
      var that = this;
    //wx.cloud.database().collection('myorder').add({
      // data 字段表示需新增的 JSON 数据
    // data: {   
     //     _id: '2', 
     //     coachid:"2002",
     //     head:"/images/driverhead/h2.jpeg",
     //     state:"未开始",
     //     day:"2021-10-12",
     //     price:205,
     //    due:"18:00-20:00",
      //    name:"订单三"     
     // }})
     db.collection('coach').get({
      success: function(res) {
        // res.data 是一个包含集合中有权限访问的所有记录的数据，不超过 20 条
        console.log("成功！！！",res.data);
        that.setData({
          mine:res.data
        })
      }
    })
  },
  xiangqing: function (event){
    console.log("lala",event.currentTarget.dataset.item._id)
    wx.navigateTo({
     url: '/pages/decor/article/articleD/articleD?id='+event.currentTarget.dataset.item._id,
    })
    },
  //筛选项点击操作
  filter: function (e) {
    var self = this, id = e.currentTarget.dataset.id, txt = e.currentTarget.dataset.txt, tabTxt = this.data.tabTxt;
    switch (e.currentTarget.dataset.index) {
      case '0':
        tabTxt[0] = txt;
        self.setData({
          tab: [true, true, true],
          tabTxt: tabTxt,
          pinpai_id: id,
          pinpai_txt: txt
        });
        break;
      case '1':
        tabTxt[1] = txt;
        self.setData({
          tab: [true, true, true],
          tabTxt: tabTxt,
          jiage_id: id,
          jiage_txt: txt
        });
        break;
      case '2':
        tabTxt[2] = txt;
        self.setData({
          tab: [true, true, true],
          tabTxt: tabTxt,
          xiaoliang_id: id,
          xiaoliang_txt: txt
        });
        break;
    }
    //数据筛选
    self.getDataList();
  },
 
  //加载数据
  getDataList:function(){
    //调用数据接口，获取数据
    var that=this;
    wx.request({
       url: 'http://192.168.1.103/json/fenxiang.json',
       method: 'GET',
       data: {},
       header: {
         'Accept': 'application/json'
       },
       //成功后的回调
       success: function (res) {
         console.log(res),
           that.setData({
           title: res.data,
           desc: res.data,
           path: 'show/show?id=' + res.data,
           })
       }
     })
    return{
      title: res.data,
      desc: res.data,
      path: 'show/show?id=' + res.data,
      success:function(res){
        wx.showToast({
          title: '转发成功'
        })
       
      },
      fail: function (res) {
        wx.showToast({
          title: '失败'
        })
 
      },
      }
    
  }
 
})
