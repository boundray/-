Page({
 
    /**
     * 页面的初始数据
     */
    data: {
      // onPullDownRefresh: function () {
      //   wx.stopPullDownRefresh()
      // },
      myinfo:[{no:'a',name:'b'}]
    
    },
   
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
      var stu = wx.getStorageSync('student');
      this.setData({ myinfo: stu });
      // console.log(this.data.myinfo);
    },
  resetpwd:function(e){
      var no=this.data.myinfo.no;
      wx.navigateTo({
        url: '../password/password?no=' + no,
      })
    },
    setemail: function (e) {
      var no = this.data.myinfo.no;
      wx.navigateTo({
        url: '../email/email?no=' + no,
      })
    }
  })
  
  