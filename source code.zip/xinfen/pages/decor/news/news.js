// index/list.js
Page({
 
    /**
     * 页面的初始数据
     */
    data: {
      tabTxt: ['车型', '价格', '星级'],//分类
      tab: [true, true, true],
      pinpai_id: 0,//车型
      pinpai_txt: '',
      jiage_id: 0,//价格
      jiage_txt: '',
      xiaoliang_id: 0,//星级
      xiaoliang_txt: '',
      dataList:[
        {
          goods_id:1,
          goods_title:'张伟',
          goods_img:'../../../images/driverhead/h1.jpeg',
          goods_pinpai:'奥迪A3',
          goods_xiaoliang:'4',
          goods_price:'150'
        },{
          goods_id:1,
          goods_title:'赵腾飞',
          goods_img:'../../../images/driverhead/h2.jpeg',
          goods_pinpai:'标致408',
          goods_xiaoliang:'3',
          goods_price:'120'
        }, {
          goods_id: 1,
          goods_title: '李敏',
          goods_img: '../../../images/driverhead/h3.jpeg',
          goods_pinpai:'红旗H5',
          goods_xiaoliang: '5',
          goods_price: '180'
        }, {
          goods_id: 1,
          goods_title: '钱大壮',
          goods_img: '../../../images/driverhead/h1.jpeg',
          goods_pinpai:'奥迪A3',
          goods_xiaoliang: '1',
          goods_price: '60'
        }, {
          goods_id: 1,
          goods_title: '于家豪',
          goods_img: '../../../images/driverhead/h2.jpeg',
          goods_pinpai:'标致408',
          goods_xiaoliang: '2',
          goods_price: '100'
        }
        , {
          goods_id: 1,
          goods_title: '陈佳',
          goods_img: '../../../images/driverhead/h3.jpeg',
          goods_pinpai:'哈弗H6',
          goods_xiaoliang: '3',
          goods_price: '110'
        }, {
          goods_id: 1,
          goods_title: '蒋国强',
          goods_img: '../../../images/driverhead/h1.jpeg',
          goods_pinpai:'奥迪A3',
          goods_xiaoliang: '2',
          goods_price: '125'
        }, {
          goods_id: 1,
          goods_title: '郭琳',
          goods_img: '../../../images/driverhead/h2.jpeg',
          goods_pinpai:'凯迪拉克',
          goods_xiaoliang: '4',
          goods_price: '160'
        }, {
          goods_id: 1,
          goods_title: '王杰',
          goods_img: '../../../images/driverhead/h1.jpeg',
          goods_pinpai:'标致408',
          goods_xiaoliang: '5',
          goods_price: '200'
        },
        {
          goods_id: 1,
          goods_title: '曹力发',
          goods_img: '../../../images/driverhead/h3.jpeg',
          goods_pinpai:'凯迪拉克',
          goods_xiaoliang: '2',
          goods_price: '70'
        }
      ],
    },
   
    // 选项卡
    filterTab: function (e) {
      var data = [true, true, true], index = e.currentTarget.dataset.index;
      data[index] = !this.data.tab[index];
      this.setData({
        tab: data
      })
    },
   
    //筛选项点击操作
    filter: function (e) {
      var self = this, id = e.currentTarget.dataset.id, txt = e.currentTarget.dataset.txt, tabTxt = this.data.tabTxt;
      switch (e.currentTarget.dataset.index) {
        case '0':
          tabTxt[0] = txt;
          self.setData({
            tab: [true, true, true],
            tabTxt: tabTxt,
            pinpai_id: id,
            pinpai_txt: txt
          });
          break;
        case '1':
          tabTxt[1] = txt;
          self.setData({
            tab: [true, true, true],
            tabTxt: tabTxt,
            jiage_id: id,
            jiage_txt: txt
          });
          break;
        case '2':
          tabTxt[2] = txt;
          self.setData({
            tab: [true, true, true],
            tabTxt: tabTxt,
            xiaoliang_id: id,
            xiaoliang_txt: txt
          });
          break;
      }
      //数据筛选
      self.getDataList();
    },
   
    //加载数据
    getDataList:function(){
      //调用数据接口，获取数据
      var that=this;
      wx.request({
         url: 'http://192.168.1.103/json/fenxiang.json',
         method: 'GET',
         data: {},
         header: {
           'Accept': 'application/json'
         },
         //成功后的回调
         success: function (res) {
           console.log(res),
             that.setData({
             title: res.data,
             desc: res.data,
             path: 'show/show?id=' + res.data,
             })
         }
       })
      return{
        title: res.data,
        desc: res.data,
        path: 'show/show?id=' + res.data,
        success:function(res){
          wx.showToast({
            title: '转发成功'
          })
         
        },
        fail: function (res) {
          wx.showToast({
            title: '失败'
          })
   
        },
        }
      
    }
   
  })
