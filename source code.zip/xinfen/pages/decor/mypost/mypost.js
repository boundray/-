// pages/decor/mypost/mypost.js
const db = wx.cloud.database();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    mine:[],
    alreadyOrder: [{
      "viewid": "4",
      "imgsrc": "../../../images/logo/friend1.png",
      "price": "¥1245",
      "count": "现在很多新手刚拿到证，就想立刻开车上路去潇洒。",
      "name": "新手司机选陪练要注意事项！",
     }, {
      "viewid": "5",
      "imgsrc": "../../../images/logo/friend2.png",
      "price": "¥2345",
      "count": "有必要，但没必要长时间找陪练,找个靠谱的老司机带你一天基本上就差不多了.",
      "name": "新手开车有必要找陪练吗？",
     }, {
      "viewid": "6",
      "imgsrc": "../../../images/logo/friend3.png",
      "price": "¥2345",
      "count": "驾校很多都教不到，因为驾校的任务是帮你考驾照，在我没有做驾校教练之前，很鄙视驾校教练。",
      "name": "找陪驾是一种什么样的体验？",
     }
     ]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    db.collection('mypost').get({
      success: function(res) {
        // res.data 是一个包含集合中有权限访问的所有记录的数据，不超过 20 条
        console.log("成功?",res.data);
        that.setData({
          mine:res.data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})