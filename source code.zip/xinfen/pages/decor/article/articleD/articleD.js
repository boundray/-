var con = require("../../../../utils/data.js");
var WxParse = require
  ("../../../../wxParse/wxParse.js");
const db = wx.cloud.database();
var app = getApp();
Page({
  data: {

    artD: {
        "nickname":"张师傅",
        "name":"张伟",
        "age":30,
        "sex":"男",
        "price":150,
        "star":4,
        "vtype":"奥迪A3",
        "insurance":"交强险",
        "freetime":{"8-10":1,"10-12":1,"2-4":1,"4-8":1}
    },
    mine:[],
    id:""
  },
  
  lianxi: function (event){
    wx.navigateTo({
     url: '../../chat/chat'
    })
    },
  yuyue: function (event){
    console.log("lala",this.data.id)
    wx.navigateTo({
      url: '../../map/map?id='+this.data.id
    })
    },
  onLoad: function (options) {
    var that = this;
    console.log("详情！",options);
    db.collection('coach').doc(options.id).get({
      success: function(res) {
        // res.data 是一个包含集合中有权限访问的所有记录的数据，不超过 20 条
        console.log("详情！",options.id,res.data);
        that.setData({
          mine:res.data,
          id:options.id
        })
      }
    })
    wx.request({

      url: con.getartical,
      data: { wxappid: con.wyy_user_wxappid, id: id },

      header: {
        "Content-Type": "application/json"
      },
      success: function (res) {


        console.log(res.data);
        WxParse.wxParse('arta', 'html', res.data.details, that,

          0);
        that.setData({
          // artD: res.data
          text: res.data.text,
          title: res.data.title,
          img: res.data.img
        })
      }
    })
  },

})

