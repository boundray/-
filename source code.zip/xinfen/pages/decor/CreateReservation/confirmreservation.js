// pages/decor/CreateReservation/confirmreservation.js
Page({
  data:{
    hidden:false,
    nocancel:false
  },
  cancel: function(){
    this.setData({
       hidden: true
    });
  },
  yuyue: function (event){
    wx.navigateTo({
      url: './successreservation'
    })
    },
  confirm: function(){
    this.setData({
       nocancel: !this.data.nocancel
    });  
    console.log("clicked confirm");
  }
})  
