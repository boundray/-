// pages/mine/mine.js
/*
var app = getApp()
Page({
  data: {
    userInfo: {},
    motto: 'Hello World',
    // orderItems
    orderItems: [
      {
        typeId: 0,
        name: '待付款',
        url: 'bill',
        imageurl: '../../../images/star/star1.png',
      },
      {
        typeId: 1,
        name: '待发货',
        url: 'bill',
        imageurl: '../../../images/star/star1.png',
      },
      {
        typeId: 2,
        name: '待收货',
        url: 'bill',
        imageurl: '../../../images/star/star1.png'
      },
      {
        typeId: 3,
        name: '待评价',
        url: 'bill',
        imageurl: '../../../images/star/star1.png'
      }
    ],
  },
  //事件处理函数
  //toOrder :事件监听，跳转到我的订单界面；onLoad：在加载过程中，获取用户的信息
  toOrder: function () {
    wx.navigateTo({
      url: '../order/order'
    })
  },
  onLoad: function () {
    console.log('onLoad')
    var that = this
    //调用应用实例的方法获取全局数据
    app.getUserInfo(function (userInfo) {
      //更新数据
      that.setData({
        userInfo: userInfo
      })
    })
  }
})
*/
// pages/user/user.js
var _app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    menuitems: [
      { text: '个人资料', url: '#', icon: '../../../images/logo/logo5.png', tips: '', arrows: '/images/user/arrows.png' },
      { text: '历史订单', url: '#', icon: '../../../images/logo/logo3.png', tips: '', arrows: '/images/user/arrows.png' },
      { text: '我的点赞', url: '#', icon: '../../../images/logo/logo7.png', tips: '', arrows: '/images/user/arrows.png' },
      { text: '我的帖子', url: '#', icon: '../../../images/logo/logo2.png', tips: '', arrows: '/images/user/arrows.png' }
    ]
  },
  order: function (event){
    wx.navigateTo({
      url: '../order/order'
    })
    },
  inform: function (event){
    wx.navigateTo({
      url: '../inform/imform'
     })
     },
  good: function (event){
    wx.navigateTo({
      url: '../good/good'
      })
      },
     mypost: function (event){
        wx.navigateTo({
          url: '../mypost/mypost'
          })
          },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  },
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  },
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  },
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  },
  
  exit:function(e){
    wx.showModal({
      title: '提示',
      content: '是否确认退出',
      success: function (res) {
        if (res.confirm) {
          // console.log('用户点击确定')
          wx.removeStorageSync('student');
          //页面跳转
          wx.redirectTo({
            url: '../../login',
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  }
})
