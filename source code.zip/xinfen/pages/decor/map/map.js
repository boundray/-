var con = require('../../../utils/data.js');
var WxParse = require("../../../wxParse/wxParse.js");
var QQMapWX = require('../../../utils/qqmap-wx-jssdk.min.js');
var app = getApp();
var lng, lat, name, address;

Page({
  data: {
    longitude: {},
    latitude: {},
    markers: [],
    show:false,//控制下拉列表的显示隐藏，false隐藏、true显示
    show2:false,
    selectData:['无','熟悉车况','培训车感','行车部分','提高阶段','综合阶段'],//下拉列表的数据
    index:0,//选择的下拉列表下标
    index2:0,
    due:["8:00-10:00","10:00-12:00","14:00-16:00","16:00-18:00"],
    inputValue1:"",
    inputValue2:"",
    mine:[]
   },
 // 点击下拉显示框
 selectTap(){
  this.setData({
   show: !this.data.show
  });
  },
  selectTap2(){
    this.setData({
     show2: !this.data.show2
    });
    },
  yuyue: function (event){
    var that = this;
    console.log("22222?",this.data.inputValue1)
    wx.cloud.database().collection('myorder').add({
      // data 字段表示需新增的 JSON 数据
     data: {   
          _id: '3', 
          coachid:this.data.mine._id,
          head:this.data.mine.head,
          state:"未开始",
          statue:"交易成功",
          day:"2021-12-30",
          price:this.data.mine.price,
         due:this.data.due[0],
          name:"订单三" ,
          type:this.data.selectData[1]
      }})
      console.log("333333")
    wx.navigateTo({
      url: '../CreateReservation/confirmreservation'
    })
    },
  // 点击下拉列表
  optionTap(e){
    console.log("yeah!!",e)
  let Index=e.currentTarget.dataset.index;//获取点击的下拉列表的下标
  this.setData({
   index:Index,
   show:!this.data.show
  });
  },
  optionTap2(e){
    console.log("yeah",e)
    let Index=e.currentTarget.dataset.index;//获取点击的下拉列表的下标
    this.setData({
     index2:Index,
     show2:!this.data.show2
    });
    },
  onLoad: function (options) {
    var that = this;
     wx.cloud.database().collection('coach').doc(options.id).get({
      success: function(res) {
        // res.data 是一个包含集合中有权限访问的所有记录的数据，不超过 20 条
        console.log("详情！",res.data);
        that.setData({
          mine:res.data
        })
        console.log("详情!!!");
      }
    })
    var that = this;
    wx.request({
      url: con.hospital_getinfo,
      method: 'GET',
      data: { wxappid: con.wyy_user_wxappid },
      header: {
        "Content-Type": "application/json"
      },
      success: function (res) {
        // console.log(res.data.info);
        name = res.data.info.name;
        address = res.data.info.address;
        WxParse.wxParse('shoperIn', 'html', res.data.info.intro, that, 0)
        that.setData({
          address: res.data.info.address,
          name: res.data.info.name,
          tel: res.data.info.tel
        })
      }

    });
    var demo = new QQMapWX({
      key: 'QCDBZ-GZ3WI-BQDG7-5H24V-Y2HSO-I7BSG'
    });
    wx.request({
      url: con.getmap,
      method: 'GET',
      data: { wxappid: con.wyy_user_wxappid },
      header: {
        "Content-Type": "application/json",
      },
      success: function (res) {
        // console.log(name);
        lng = res.data.lng;
        lat = res.data.lat;
        that.setData({
          longitude: res.data.lng,
          latitude: res.data.lat,
          
          markers: [{
            longitude: res.data.lng,
            latitude: res.data.lat,
            iconPath: '../../../images/map/map.png',
            title: name,
            address: address,
            alpha: 1,
            width: 40,
            height: 40
          }],
        });
      }
    });

  },
  bindgothere: function (e) {

    wx.openLocation({
      latitude: lat,
      longitude: lng,
      name: name,
      address: address
    })
  },

  data2:{
    focus:false,
    inputValue1:"",
    inputValue2:""
    },
    bindButtonTap:function(){
    this.setData({
    focus:Date.now()
    })
    },
    bindKeyInput:function(e){
    this.setData({
    inputValue1:e.detail.value,
    inputValue2:e.detail.value
    }),
    console.log("success",e.detail.value)
    },
    test:function(e){
      console.log("success")
    },
    bindReplaceInput:function(e){
    var value = e.detail.value;
    var pos = e.detail.cursor;
    if(pos != -1){
    //光标在中间
    var left = e.detail.value.slice(0,pos);
    //计算光标的位置
    pos = left.replace(/11/g,'2').length;
    }}
});




