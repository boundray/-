const db = wx.cloud.database();
Page({
 
  /**
  * 页面的初始数据
  */
  data: {
  weibos: ["新手司机和老司机的区别，怎么操作才能省时省力又省钱！",
  "新手司机要想找个靠谱陪练，要关注哪些细节？",
  ],
  mine:[]
  },
  onLoad: function (options) {
    var that = this;
    console.log("详情！",options);
    db.collection('zixun').doc(options.id).get({
      success: function(res) {
         //res.data 是一个包含集合中有权限访问的所有记录的数据，不超过 20 条
        console.log("详情！!",options.id,res.data);
        that.setData({
          mine:res.data,
       })
      }
    })
  },

  exit:function(e){
    wx.showModal({
      title: '提示',
      content: '点赞成功',
      success: function (res) {
        if (res.confirm) {
          // console.log('用户点击确定')
          wx.removeStorageSync('student');
          //页面跳转
          wx.redirectTo({
            url: '../po/po.js',
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  
  writeweibo: function (event){
  wx.navigateTo({
   url: 'writepo/writepo'
  })
  },
 })