// pages/post/post.js
// pages/circle/list.js
var that;
Page({

 /**
 * 页面的初始数据
 */
 data: {
 userInfo:null,
 list:[],
 // 当前点击操作面板的索引，每条朋友圈一个面板
 showOperationPannelIndex:-1,
 },

 /**
 * 生命周期函数--监听页面加载
 */
 onLoad: function (options) {
 that = this;
 for (var i = 1; i < 10; i++) {
  // 定义一个对象存储数据
  var circleData = {};
  circleData.nickName = "朋友-" + i;
  circleData.content = "朋友发布内容-" + i;
  circleData.time = "2020-05-0" + i;

  //图片列表
  var imageList = [];
  // 点赞列表
  var loveList = [];
  // 评论列表
  var commentList = [];


  // 这三个数组赋值给circleData
  circleData.imageList = imageList;
  circleData.loveList = loveList;
  circleData.commentList = commentList;

  // 给3个数组赋值
  for (var j = 1; j < i; j++) {
  // 图片路径，占位
  imageList.push(j);
  // loveList，定义loveData对象
  var loveData = {};
  loveData.nickName = '点赞-' + j;
  // 点赞数组加入loveList
  loveList.push(loveData);

  // 评论数据
  var commentData = {};
  commentData.nickName = "兰陵王-" + j + "：";
  commentData.content = "评论内容-" + j;
  // 加入数据
  commentList.push(commentData);
  }

  that.data.list.push(circleData);
 }
 // 重新渲染
 that.setData({
  list: that.data.list
 })
 //获取用户信息
 wx.getStorage({
  key: 'userInfo',
  success(res){
  //转换成对象
  console.log("getStorage success:",JSON.parse(res.data));
  that.setData({
   userInfo:JSON.parse(res.data)
  })
  }
 })
 },
 //控制操作面板展示
 showOperationPannel(e){
 console.log("showOperationPannel",e);
 // 获取点击的索引
 var index = e.currentTarget.dataset.index;
 // 如果正在展示，则关闭
 if(that.data.showOperationPannelIndex == index){
  that.setData({
  // 索引从0开始
  showOperationPannelIndex:-1
  })
 }
 else{
  that.setData({
  // 设置成当前点击的索引
  showOperationPannelIndex:index
  })
 }
 
 },
 // 点赞功能
 clickLove(e){
 console.log(e);
 var index = e.currentTarget.dataset.index;
 // 将这条数据取出
 var circleData = that.data.list[index];
 var loveList = circleData.loveList;
 var isHaveLove = false;
 for(var i = 0; i < loveList.length; i++){
  if(that.data.userInfo.nickName == loveList[i].nickName){
  isHaveLove = true;
  // 移除点赞
  loveList.splice(i,1);
  break;
  }
 }

 if(!isHaveLove){
  loveList.push({nickName:that.data.userInfo.nickName});
 }
 that.setData({
  list:that.data.list,
  // 关闭点赞评论面板
  showOperationPannelIndex:-1
 })

 },
 
})