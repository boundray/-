const db = wx.cloud.database();
Page({
 
  /**
  * 页面的初始数据
  */
  data: {
  weibos: ["新手司机和老司机的区别，怎么操作才能省时省力又省钱！",
  "新手司机要想找个靠谱陪练，要关注哪些细节？",
  ],
  mine:[],
  id:""
  },
 
  exit:function(e){
    var that = this;
    wx.cloud.database().collection('mylike').add({
      // data 字段表示需新增的 JSON 数据
     data: {   
          _id: this.data.mine._id, 
          abstract:this.data.mine.abstract,
          head:this.data.mine.head,
          likenum:this.data.mine.likenum,
          comment:this.data.mine.comment,
     mainbody:this.data.mine.mainbody,
      posttime:this.data.mine.posttime ,   
      title:this.data.mine.title
      }})

    wx.showModal({
      title: '提示',
      content: '点赞成功',
      success: function (res) {
        if (res.confirm) {
          // console.log('用户点击确定')
          wx.removeStorageSync('student');
          //页面跳转
          wx.redirectTo({
            url: '../po/po.js',
          })
        } else if (res.cancel) {
          console.log('用户点击取消')
        }
      }
    })
  },
  onLoad: function (options) {
    var that = this;
    that.setData({
      id:options.id,
   })
    console.log("详情！",options);
    db.collection('post').doc(options.id).get({
      success: function(res) {
         //res.data 是一个包含集合中有权限访问的所有记录的数据，不超过 20 条
        console.log("详情！!",options.id,res.data);
        that.setData({
          mine:res.data,
       })
      }
    })
  },

  writeweibo: function (event){
    console.log("hahah",this.data.id)
  wx.navigateTo({
    url: 'writepo/writepo?id='+this.data.id,

  })
  },
 })