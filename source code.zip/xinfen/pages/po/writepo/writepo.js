// pages/weibo/top/top.js
const db = wx.cloud.database();
const _ = db.command;
Page({
 
    /**
    * 页面的初始数据
    */
    data: {
    id:""
    },
    
    
    /**
    * 生命周期函数--监听页面加载
    */
    onLoad: function (options) {
        var that = this;
        that.setData({
          id:options.id,
       })
    },
    
    /**
    * 生命周期函数--监听页面初次渲染完成
    */
    onReady: function () {
    
    },
    
    /**
    * 生命周期函数--监听页面显示
    */
    onShow: function () {
    
    },
    
    submitEvent:function(event){
    console.log("11111")
    var content = event.detail.value.content;
    
    console.log("4444","小企鹅："+event.detail.value.content)
    db.collection('post').doc(this.data.id).update({
        
        data: {
          // 表示指示数据库将字段自增 10
          comment: _.push("小企鹅："+event.detail.value.content)
        },
        
      })
   
    console.log("22222")
    wx.navigateBack({
        delta: 1,
      })
    
    }
   })