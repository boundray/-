Page({
  onTap: function (event) {
    wx.navigateTo({
     url:"../pages/decor/home/home"
   });
    
   //wx.switchTab({
    //url: "../posts/post"
   //});
    
  },
  startjourney:function (event){
    wx.navigateTo({
      url:"../pages/decor/home/home"
    });
    },
  onReachBottom:function(event){
   console.log('asfasdfa')
  }
 })